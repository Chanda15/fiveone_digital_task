<?php

namespace App\Http\Controllers;
use App\Models\Posts;
use App\Models\Comments;
use Illuminate\Http\Request;
use Auth;
class PostsController extends Controller
{
	/**
	* Display a listing of the resource.
	*
	* @return \Illuminate\Http\Response
	*/
	public function index()
	{
		$data['posts'] = Posts::orderBy('id','desc')->paginate(5);
		return view('posts.index', $data);
	}
	public function post_comments()
	{
		$posts = Posts::all();
		$Data_Post = array();
		foreach($posts as $post_data){
			$posts_comments = Posts::find($post_data->id)->comments;
			$Data_Post[] = array(
				'id'=>$post_data->id,
				'post_name'=>$post_data->post_name,
				'post_details'=>$post_data->post_details,
				'posted_on'=>date('d-m-Y', strtotime($post_data->posted_on)),
				'posts_comments'=>$posts_comments,
			);
		}
		$data['posts']= json_encode($Data_Post);
		//echo '<pre>';
		//print_r($Data_Post); exit;
		return view('posts.post_comments', $data);
	}
	/**
	* Show the form for creating a new resource.
	*
	* @return \Illuminate\Http\Response
	*/
	public function create()
	{
		return view('posts.create');
	}
	/**
	* Store a newly created resource in storage.
	*
	* @param  \Illuminate\Http\Request  $request
	* @return \Illuminate\Http\Response
	*/
	public function store(Request $request)
	{
		$request->validate([
		//'user_id' => 'required',
		'post_name' => 'required',
		'post_details' => 'required',
		]);
		$Posts = new Posts;
		$Posts->post_name = $request->post_name;
		$Posts->post_details = $request->post_details;
		$Posts->user_id = Auth::id();
		$Posts->posted_on = date('Y-m-d');
		$Posts->save();
		return redirect()->route('posts')
		->with('success','Posts has been created successfully.');
	}
	/**
	* Display the specified resource.
	*
	* @param  \App\Posts  $Posts
	* @return \Illuminate\Http\Response
	*/
	public function show(Posts $Posts)
	{
		return view('posts.show',compact('Posts'));
	} 
	/**
	* Show the form for editing the specified resource.
	*
	* @param  \App\Posts  $Posts
	* @return \Illuminate\Http\Response
	*/
	public function edit($PostId)
	{
		$Posts = Posts::find($PostId);
		return view('posts.edit',compact('Posts'));
	}
	/**
	* Update the specified resource in storage.
	*
	* @param  \Illuminate\Http\Request  $request
	* @param  \App\Posts  $Posts
	* @return \Illuminate\Http\Response
	*/
	public function update(Request $request)
	{
		$request->validate([
		'post_name' => 'required',
		'post_details' => 'required',
		]);
		$Posts = Posts::find($request->PostId);
		$Posts->post_name = $request->post_name;
		$Posts->post_details = $request->post_details;
		$Posts->user_id = Auth::id();
		$Posts->save();
		return redirect()->route('posts')
		->with('success','Posts Has Been updated successfully');
	}
	/**
	* Remove the specified resource from storage.
	*
	* @param  \App\Posts  $Posts
	* @return \Illuminate\Http\Response
	*/
	public function delete($PostId)
	{
		$Posts = Posts::find($PostId);
		$Posts->delete();
		return redirect()->route('posts')
		->with('success','Posts has been deleted successfully');
	}
	public function submit_post_comments(Request $request)
	{
		$Comments = new Comments;
		$Comments->post_comments = $request->comments;
		$Comments->posts_id = $request->post_id;
		$Comments->user_id = Auth::id();
		//$Posts->posted_on = date('Y-m-d');
		$Comments->save();
		//return redirect()->route('post_comments')->with('success','Posts has been created successfully.');
		
	}
}
