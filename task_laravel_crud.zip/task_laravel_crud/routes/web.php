<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
 
Route::get('/post_comments', 'PostsController@post_comments')->name('posts');
Route::get('/posts', 'PostsController@index')->name('posts');
Route::get('/posts_create', 'PostsController@create')->name('posts_create');
Route::post('/posts_update', 'PostsController@update')->name('posts_update');
Route::get('/posts_edit/{PostId}', 'PostsController@edit')->name('posts_edit');
Route::get('/posts_delete/{PostId}', 'PostsController@delete')->name('posts_delete');
Route::post('/post_store', 'PostsController@store')->name('post_store');
Route::post('/submit_post_comments', 'PostsController@submit_post_comments')->name('submit_post_comments');
