@extends('layouts.app')

@section('content')
<div class="container mt-2">
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-left">
<h2>Edit Post</h2>
</div>
<div class="pull-right">
<a class="btn btn-primary" href="{{ route('posts') }}" enctype="multipart/form-data"> Back</a>
</div>
</div>
</div>
@if(session('status'))
<div class="alert alert-success mb-1 mt-1">
{{ session('status') }}
</div>
@endif
<form action="{{ route('posts_update') }}" method="POST" enctype="multipart/form-data">
@csrf
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Posts name:</strong>
<input type="text" name="post_name" value="{{ $Posts->post_name }}" class="form-control" placeholder="Post name">
@error('post_name')
<div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
@enderror
</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Post Details:</strong>
<textarea  name="post_details" class="form-control" placeholder="Description" required>{{ $Posts->post_details }}</textarea>
@error('post_details')
<div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
@enderror
</div>
</div>
<input type="hidden" name="PostId" value="{{$Posts->id}}">
<button type="submit" class="btn btn-primary ml-3">Submit</button>
</div>
</form>
</div>
@endsection
