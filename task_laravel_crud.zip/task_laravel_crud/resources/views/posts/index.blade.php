@extends('layouts.app')

@section('content')
<div class="container mt-2">
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-left">
<h2>Posts Crud Operation</h2>
</div>
<div class="pull-right mb-2">
<a class="btn btn-success" href="{{ route('posts_create') }}"> Create Post</a>
</div>
</div>
</div>
@if ($message = Session::get('success'))
<div class="alert alert-success">
<p>{{ $message }}</p>
</div>
@endif
<table class="table table-bordered">
<tr>
<th>S.No</th>
<th>Post Name</th>
<th>Details</th>
<th>Post Date</th>
<th width="280px">Action</th>
</tr>
@foreach ($posts as $post_data)
<tr>
<td>{{ $post_data->id }}</td>
<td>{{ $post_data->post_name }}</td>
<td>{{ $post_data->post_details }}</td>
<td>{{ $post_data->posted_on }}</td>
<td>
<a class="btn btn-danger" href="{{ url('posts_delete/'.$post_data->id) }}">Delete</a>
<a class="btn btn-primary" href="{{ url('posts_edit/'.$post_data->id) }}">Edit</a>
</td>
</tr>
@endforeach
</table>
{!! $posts->links() !!}
@endsection
