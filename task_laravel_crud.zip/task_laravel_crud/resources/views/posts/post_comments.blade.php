@extends('layouts.app')

@section('content')
<div class="container mt-2">
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-left">
<h2>All Post</h2>
</div>
<div class="pull-right mb-2">

</div>
</div>
</div>
@if ($message = Session::get('success'))
<div class="alert alert-success">
<p>{{ $message }}</p>
</div>
@endif
@php
//print_r($posts_comments);
$posts_json_decode = json_decode($posts);
@endphp
@foreach ($posts_json_decode as $post_data)
<div class="col-md-12" style="border:1px solid #ddd;">
<h1>{{ $post_data->post_name }}</h1>
<span>{{ $post_data->posted_on }}</span>
<p>{{ $post_data->post_details }}</p>
<form >
<textarea  name="comments" id="comments_{{ $post_data->id }}" class="form-control" placeholder="Comments" required></textarea>
<input type="hidden" name="post_id" id="PostId_{{ $post_data->id }}" value="{{ $post_data->id }}">
<input type="button" class="btn btn-primary" value="Submit" onclick="return submitComments({{ $post_data->id }})">
</form>
<div class="comments_box">

@foreach($post_data->posts_comments as $post_comment_data)
<p>{{ $post_comment_data->post_comments }}</p>
@endforeach
</div>
</div>
@endforeach
<script>
function submitComments(PostId){
	var comments = $('#comments_'+PostId).val();
	$.ajax({
	type:"POST",
	url:"{{url('submit_post_comments')}}",
	data:{
		comments:comments,
		post_id:PostId,
		"_token": "{{ csrf_token() }}",
		},
		success:function(response){
			$('#comments_'+PostId).val('');
			$('.comments_box').append('<p>'+comments+'</p>');
			//console.log(response);
		},
	});
}
</script>
@endsection
