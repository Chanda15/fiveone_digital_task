<?php $__env->startSection('content'); ?>
<div class="container mt-2">
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-left">
<h2>All Post</h2>
</div>
<div class="pull-right mb-2">

</div>
</div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<?php
//print_r($posts_comments);
$posts_json_decode = json_decode($posts);
?>
<?php $__currentLoopData = $posts_json_decode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12" style="border:1px solid #ddd;">
<h1><?php echo e($post_data->post_name); ?></h1>
<span><?php echo e($post_data->posted_on); ?></span>
<p><?php echo e($post_data->post_details); ?></p>
<form >
<textarea  name="comments" id="comments_<?php echo e($post_data->id); ?>" class="form-control" placeholder="Comments" required></textarea>
<input type="hidden" name="post_id" id="PostId_<?php echo e($post_data->id); ?>" value="<?php echo e($post_data->id); ?>">
<input type="button" class="btn btn-primary" value="Submit" onclick="return submitComments(<?php echo e($post_data->id); ?>)">
</form>
<div class="comments_box">

<?php $__currentLoopData = $post_data->posts_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_comment_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p><?php echo e($post_comment_data->post_comments); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
function submitComments(PostId){
	var comments = $('#comments_'+PostId).val();
	$.ajax({
	type:"POST",
	url:"<?php echo e(url('submit_post_comments')); ?>",
	data:{
		comments:comments,
		post_id:PostId,
		"_token": "<?php echo e(csrf_token()); ?>",
		},
		success:function(response){
			$('#comments_'+PostId).val('');
			$('.comments_box').append('<p>'+comments+'</p>');
			//console.log(response);
		},
	});
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\task_laravel_crud\resources\views/posts/post_comments.blade.php ENDPATH**/ ?>